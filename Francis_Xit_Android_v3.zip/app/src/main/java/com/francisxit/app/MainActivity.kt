package com.francisxit.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg=Color(0xFF05070D); private val Card=Color(0xFF0C1220); private val Blue=Color(0xFF1597FF); private val Purple=Color(0xFF9B35FF)

data class Game(val name:String,val category:String,val icon:String,val description:String,val playUrl:String)

val games=listOf(
    Game("Free Fire","Ação • Battle Royale","🔥","Battle royale para partidas rápidas e competitivas.","https://play.google.com/store/apps/details?id=com.dts.freefireth"),
    Game("Minecraft","Aventura • Construção","⛏️","Explore, construa e sobreviva em um mundo de blocos.","https://play.google.com/store/apps/details?id=com.mojang.minecraftpe"),
    Game("Roblox","Aventura • Multiplayer","🎮","Jogue experiências criadas pela comunidade.","https://play.google.com/store/apps/details?id=com.roblox.client"),
    Game("Subway Surfers","Corrida • Arcade","🏃","Corra, desvie dos obstáculos e supere seus recordes.","https://play.google.com/store/apps/details?id=com.kiloo.subwaysurf")
)

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{FrancisXitApp()}}
}

@Composable fun FrancisXitApp(){
    var selected by remember{mutableStateOf(0)}
    var opened by remember{mutableStateOf<Game?>(null)}
    var favorites by remember{mutableStateOf(setOf<String>())}

    MaterialTheme(colorScheme=darkColorScheme(background=Bg,surface=Card,primary=Blue)){
        if(selected==3 && opened==null){
            ProfileScreen()
        }else if(opened!=null){
            GameDetail(opened!!, favorites.contains(opened!!.name),
                onBack={opened=null},
                onFavorite={g->favorites=if(favorites.contains(g.name)) favorites-g.name else favorites+g.name})
        }else{
            Scaffold(containerColor=Bg,bottomBar={
                NavigationBar(containerColor=Color(0xFF070A12)){
                    listOf(Icons.Default.Home to "Início",Icons.Default.SportsEsports to "Jogos",Icons.Default.Star to "Favoritos",Icons.Default.Person to "Perfil").forEachIndexed{index,item->
                        NavigationBarItem(selected=selected==index,onClick={selected=index},icon={Icon(item.first,null)},label={Text(item.second)})
                    }
                }
            }){p->HomeScreen(Modifier.padding(p),games,favorites){opened=it}}
        }
    }
}

@Composable fun HomeScreen(modifier:Modifier,games:List<Game>,favorites:Set<String>,open:(Game)->Unit){
    var query by remember{mutableStateOf("")}
    val filtered=games.filter{it.name.contains(query,true)||it.category.contains(query,true)}
    Column(modifier.fillMaxSize().background(Bg).padding(horizontal=16.dp).verticalScroll(rememberScrollState())){
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Icon(Icons.Default.Menu,null,tint=Color.White,modifier=Modifier.size(30.dp));Icon(Icons.Default.Notifications,null,tint=Color.White,modifier=Modifier.size(28.dp))}
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF101C38),Color(0xFF070A12))),RoundedCornerShape(24.dp)).padding(20.dp)){
            Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.fillMaxWidth()){
                Text("👑",fontSize=42.sp);Text("FRANCIS",fontSize=42.sp,fontWeight=FontWeight.Black,color=Color.White);Text("XIT",fontSize=48.sp,fontWeight=FontWeight.Black,color=Blue);Text("JOGOS",fontSize=18.sp,fontWeight=FontWeight.Bold,color=Color.White)
            }
        }
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),placeholder={Text("Pesquisar jogos...")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,shape=RoundedCornerShape(30.dp))
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){QuickCard("🎮","Jogos",Modifier.weight(1f));QuickCard("⭐","${favorites.size} Favoritos",Modifier.weight(1f));QuickCard("👤","Perfil",Modifier.weight(1f))}
        Spacer(Modifier.height(24.dp));Text("🔥 Jogos",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.ExtraBold);Spacer(Modifier.height(10.dp))
        filtered.forEach{g->GameCard(g,favorites.contains(g.name)){open(g)};Spacer(Modifier.height(12.dp))}
        Spacer(Modifier.height(24.dp))
    }
}

@Composable fun QuickCard(icon:String,title:String,modifier:Modifier){Column(modifier.height(100.dp).background(Card,RoundedCornerShape(16.dp)).padding(10.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text(icon,fontSize=25.sp);Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=12.sp)}}

@Composable fun GameCard(g:Game,fav:Boolean,open:(Game)->Unit){
    Row(Modifier.fillMaxWidth().background(Card,RoundedCornerShape(18.dp)).clickable{open(g)}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){
        Box(Modifier.size(82.dp).background(Brush.linearGradient(listOf(Color(0xFF102A55),Color(0xFF32114B))),RoundedCornerShape(14.dp)),contentAlignment=Alignment.Center){Text(g.icon,fontSize=42.sp)}
        Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(g.name,color=Color.White,fontSize=18.sp,fontWeight=FontWeight.Bold);Text(g.category,color=Color(0xFF9DAAC4),fontSize=12.sp);Text(if(fav)"⭐ Favorito" else "Toque para ver detalhes",color=Blue,fontSize=11.sp)}
        Icon(Icons.Default.ChevronRight,null,tint=Color.White)
    }
}


@Composable fun ProfileScreen(){
    var name by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().background(Bg).padding(20.dp)
            .verticalScroll(rememberScrollState())
    ){
        Text("👤", fontSize=58.sp)
        Spacer(Modifier.height(8.dp))
        Text("Meu Perfil", color=Color.White, fontSize=30.sp, fontWeight=FontWeight.Black)
        Text("Personalize seu perfil no Francis Xit", color=Color(0xFF9DAAC4), fontSize=14.sp)

        Spacer(Modifier.height(24.dp))
        Box(
            Modifier.fillMaxWidth().height(130.dp)
                .background(Brush.linearGradient(listOf(Color(0xFF102A55),Color(0xFF32114B))),RoundedCornerShape(22.dp)),
            contentAlignment=Alignment.Center
        ){ Text(if(name.isBlank()) "🎮" else "👑", fontSize=60.sp) }

        Spacer(Modifier.height(18.dp))
        OutlinedTextField(
            value=name,
            onValueChange={name=it;saved=false},
            modifier=Modifier.fillMaxWidth(),
            label={Text("Nome do jogador")},
            placeholder={Text("Digite seu nome")},
            singleLine=true,
            shape=RoundedCornerShape(16.dp)
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick={saved=true},
            modifier=Modifier.fillMaxWidth().height(52.dp),
            shape=RoundedCornerShape(16.dp)
        ){
            Icon(Icons.Default.Save,null)
            Spacer(Modifier.width(8.dp))
            Text("SALVAR PERFIL",fontWeight=FontWeight.Bold)
        }

        if(saved){
            Spacer(Modifier.height(10.dp))
            Text("✅ Perfil salvo neste aparelho.",color=Color(0xFF7DFFB2),fontWeight=FontWeight.Bold)
        }

        Spacer(Modifier.height(28.dp))
        Text("⚙️ Configurações",color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        SettingRow("🔔","Notificações")
        SettingRow("🌙","Modo escuro")
        SettingRow("ℹ️","Sobre o Francis Xit")
    }
}

@Composable fun SettingRow(icon:String,title:String){
    Row(
        Modifier.fillMaxWidth().padding(vertical=6.dp)
            .background(Card,RoundedCornerShape(14.dp)).padding(16.dp),
        verticalAlignment=Alignment.CenterVertically
    ){
        Text(icon,fontSize=24.sp)
        Spacer(Modifier.width(12.dp))
        Text(title,color=Color.White,fontSize=15.sp,fontWeight=FontWeight.SemiBold)
        Spacer(Modifier.weight(1f))
        Icon(Icons.Default.ChevronRight,null,tint=Color(0xFF8FA2C5))
    }
}

@Composable fun GameDetail(g:Game,isFav:Boolean,onBack:()->Unit,onFavorite:(Game)->Unit){
    val context=LocalContext.current
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(16.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null,tint=Color.White)}
            Text("DETALHES",color=Color.White,fontWeight=FontWeight.Bold)
            IconButton(onClick={onFavorite(g)}){Icon(if(isFav)Icons.Default.Star else Icons.Default.StarBorder,null,tint=if(isFav)Color.Yellow else Color.White)}
        }
        Spacer(Modifier.height(18.dp))
        Box(Modifier.fillMaxWidth().height(190.dp).background(Brush.linearGradient(listOf(Color(0xFF102A55),Color(0xFF32114B))),RoundedCornerShape(24.dp)),contentAlignment=Alignment.Center){Text(g.icon,fontSize=90.sp)}
        Spacer(Modifier.height(18.dp));Text(g.name,color=Color.White,fontSize=32.sp,fontWeight=FontWeight.Black);Text(g.category,color=Blue,fontSize=14.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(12.dp));Text(g.description,color=Color(0xFFCCD5E8),fontSize=16.sp,lineHeight=23.sp)
        Spacer(Modifier.height(28.dp))
        Button(onClick={context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(g.playUrl)))},modifier=Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(16.dp)){Icon(Icons.Default.PlayArrow,null);Spacer(Modifier.width(8.dp));Text("JOGAR / ABRIR NA PLAY STORE",fontWeight=FontWeight.Bold)}
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick={onFavorite(g)},modifier=Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(16.dp)){Icon(if(isFav)Icons.Default.Star else Icons.Default.StarBorder,null);Spacer(Modifier.width(8.dp));Text(if(isFav)"REMOVER DOS FAVORITOS" else "ADICIONAR AOS FAVORITOS")}
    }
}
