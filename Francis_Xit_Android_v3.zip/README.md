# Francis Xit — Android

Projeto inicial do aplicativo gamer Francis Xit.

## Como abrir
1. Instale o Android Studio.
2. Abra esta pasta como projeto.
3. Aguarde o Gradle baixar as dependências.
4. Execute em um celular Android ou emulador.

## Próximas etapas
- cadastrar jogos reais e links oficiais;
- tela de detalhes de cada jogo;
- favoritos funcionando;
- perfil;
- busca funcionando;
- banco de dados;
- login, se desejado;
- publicação na Google Play.

Observação: os cards de jogos desta primeira versão são apenas demonstrativos.
